whoami
 sudo -i -u $1 bash << EOF
 echo "Changing the user to - "$1
 whoami
 isDirPresent=$(ls -l /stage/$1|wc -l )
 echo "output - "$isDirPresent

  if [[ $isDirPresent=="0" ]]; then
    echo "/stage/"$1" not present - creating it"
    cd /stage
    mkdir $1
    chmod 777 $1
  fi

 cd /stage/$1
 cp CURRENT_PATH/TestData/*.zip .
 pwd

echo " find wala"
find . -name "*.zip" -exec unzip {} \;

EOF
echo "Out"
whoami
