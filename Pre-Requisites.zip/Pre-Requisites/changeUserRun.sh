whoami
sudo -i -u $1 bash << EOF
echo "In" 
whoami
/usr/bin/sh CURRENT_PATH/copyTestData.sh $1
EOF
echo "Out"
whoami


