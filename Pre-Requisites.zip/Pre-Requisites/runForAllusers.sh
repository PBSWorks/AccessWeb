echo "##########################################"
for i in `more userlist.txt `
do
echo "user - ""$i "
/usr/bin/sh CURRENT_PATH/changeUserRun.sh $i
echo "###########################################"
done


