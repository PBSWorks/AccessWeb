cp CURRENT_PATH/PrePost/MultipleFilesJS.zip .
/usr/bin/unzip MultipleFilesJS.zip

cp CURRENT_PATH/PrePost/MultipleFilesIconsJS.zip .
/usr/bin/unzip MultipleFilesIconsJS.zip

cp CURRENT_PATH/PrePost/MultipleFolderJS.zip .
/usr/bin/unzip MultipleFolderJS.zip

cp CURRENT_PATH/PrePost/MultipleFolderIconsJS.zip .
/usr/bin/unzip MultipleFolderIconsJS.zip

cp CURRENT_PATH/PrePost/MultipleFolderFilesJS.zip .
/usr/bin/unzip MultipleFolderFilesJS.zip

cp CURRENT_PATH/PrePost/MultipleFolderFilesIconsJS.zip .
/usr/bin/unzip MultipleFolderFilesIconsJS.zip


