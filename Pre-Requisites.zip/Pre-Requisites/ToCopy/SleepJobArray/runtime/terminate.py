#!/usr/bin/python
print("terminate script")
