#!/usr/bin/python

import time
import os
import sys

script=sys.argv[0]
title = ""
if 'PAS_ACTION_TITLE' in os.environ:
    title=os.environ['PAS_ACTION_TITLE']
else:
    print("error: expected PAS_ACTION_TITLE variable not found")
    exit(106)

print("Executing script: " + script + " with title : " + title)
sys.stdout.flush()
