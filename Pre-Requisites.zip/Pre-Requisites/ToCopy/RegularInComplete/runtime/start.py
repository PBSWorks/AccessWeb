#
# (c) Copyright 2017 Altair Engineering, Inc.  All rights reserved.
#
# This code is provided as is without any warranty, express or implied,
# or indemnification of any kind.
# All other terms and conditions are as specified in the Altair PBS EULA.
#
import time, os, sys, re, subprocess

Debug = False 

job_script      = os.path.basename(os.environ['PRIMARY_FILE'])
job_args        = os.environ['JOB_ARGS']
python_path     = os.environ['PYTHONPATH']

# TODO: Standardize job script line endings for better multiplaform/editor compatibility.

job_script = job_script.replace('%20',' ')
if Debug:
    print("start.py: script: " + job_script)  

file = open( job_script, 'r' )
line = file.readline()
file.close()

argsUnescaped = []
rc = 0
if (len(job_args)>0):

    args = job_args.split(' ')
    for arg in args:
        if (arg.strip()):
            arg = arg.replace('%20',' ')
            argsUnescaped.append(arg) 

if line.startswith('#!'):
    if Debug:
        print("start.py: #! detected")  

    try:
        interpreter = re.match( '^#!(.*)', line ).group(1)
        interpreter = interpreter.rstrip()
        if interpreter.endswith("sh") or interpreter.endswith("bash"):
            os.rename(job_script, job_script + '.bak')
            fh = open(job_script,"w")
            for line in open(job_script+'.bak'):
                line = line.rstrip()
                fh.write(line + '\n')
            fh.close()
            os.remove(job_script+".bak")
        command = [interpreter] + [job_script] + argsUnescaped
        if Debug:
            print("start.py: executing:")  
            print(command)  

        sys.stdout.flush()            
        sys.stderr.flush()            
        res = subprocess.Popen(command, shell=False)
        res.communicate()
        sys.stdout.flush()            
        sys.stderr.flush()            
        rc = res.returncode
       
    except OSError as err:
        print('An error occurred while initiating the Job Script.', file=sys.stderr)        

else:
    print("start.py: No #! line detected in Job Script, defaulting to Python.")
    try:
        command = [python_path] + [job_script] + argsUnescaped
        if Debug:
            print("start.py: executing:")  
            print(command)  

        sys.stdout.flush()            
        sys.stderr.flush()            
        res = subprocess.Popen(command, shell=False)
        res.communicate()
        sys.stdout.flush()            
        sys.stderr.flush()            
        rc = res.returncode
 
    except OSError as err:
        print('An error occurred while initiating the Job Script.', file=sys.stderr)
       
if Debug:
    print("start.py: rc : " + str(rc))  
    
sys.stdout.flush()
sys.stderr.flush()
# return the exit code from application script
sys.exit(rc)